package logica;

import java.util.ArrayList;

public class Becas {
    private ArrayList<Estudiantes> estudiantes;

    public Becas() {
        estudiantes = new ArrayList<Estudiantes>();
    }

    public void agregarEstudiante(Estudiantes estudiante) {
        estudiantes.add(estudiante);
    }

    public ArrayList<Estudiantes> obtenerEstudiantes() {
        return estudiantes;
    }

    public Estudiantes buscarPorCedula(String cedula) {
        for (Estudiantes est : estudiantes) {
            if (est.getCedula().equals(cedula)) {
                return est;
            }
        }
        return null;
    }

    public ArrayList<Estudiantes> buscarPorCarrera(String carrera) {
        ArrayList<Estudiantes> resultado = new ArrayList<Estudiantes>();
        for (Estudiantes est : estudiantes) {
            if (est.getCarrera().equalsIgnoreCase(carrera)) {
                resultado.add(est);
            }
        }
        return resultado;
    }

    public ArrayList<Estudiantes> buscarPorSexo(String sexo) {
        ArrayList<Estudiantes> resultado = new ArrayList<Estudiantes>();
        for (Estudiantes est : estudiantes) {
            if (est.getSexo().equalsIgnoreCase(sexo)) {
                resultado.add(est);
            }
        }
        return resultado;
    }
}
