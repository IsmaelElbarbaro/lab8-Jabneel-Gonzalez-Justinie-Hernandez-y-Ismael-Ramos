package logica;

public class Estudiantes {
    private String nombre;
    private String carrera;
    private double indice;
    private String cedula;
    private String sexo;
    
    public Estudiantes(String nombre, String carrera, double indice, String cedula, String sexo) throws Exception {
        if (indice < 0 || indice > 3) {
            throw new Exception("El índice debe estar entre 0 y 3.");
        }
        this.nombre = nombre;
        this.carrera = carrera;
        this.indice = indice;
        this.cedula = cedula;
        this.sexo = sexo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCarrera() {
        return carrera;
    }

    public double getIndice() {
        return indice;
    }

    public String getCedula() {
        return cedula;
    }

    public String getSexo() {
        return sexo;
    }
}
