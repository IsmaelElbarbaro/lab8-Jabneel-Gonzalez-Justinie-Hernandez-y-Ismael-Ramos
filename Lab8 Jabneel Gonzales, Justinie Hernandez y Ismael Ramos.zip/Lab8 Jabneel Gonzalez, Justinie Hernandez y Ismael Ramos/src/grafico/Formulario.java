package grafico;

import javax.swing.*;
import java.awt.event.*;
import logica.*;
import java.util.ArrayList;

public class Formulario extends JFrame implements ActionListener {
    private JTextField txtNombre, txtIndice, txtCedula, txtBuscarCedula;
    private JComboBox<String> comboCarrera, comboSexo;
    private JButton btnAgregar, btnBuscarCedula, btnBuscarCarrera, btnBuscarSexo, btnReportes;
    private Becas becas;
    private String[] carreras = {
        "TEC. PROGRAMACION Y ANALISIS",
        "TEC. EN INFORM. GESTION EMPR.",
        "POSTGRADO AUDITORIA DE SIST.",
        "POSTG.ING.SOFTW.APLIC",
        "MAESTRÍA EN SEGURIDAD INFORMÁT",
        "POSTG. COMERCIO ELECTRONICO",
        "POSTG. INF. APLICADA EDUCAC.",
        "POSTG.EN REDES COMUN.DATOS",
        "LIC EN INGENIERÍA DE SOFTWARE",
        "LIC. EN DESAR. Y GEST. DE SOF.",
        "LIC.ING.SIST.INFORM.",
        "LIC. REDES INFORMATICAS",
        "LIC.DESARR.SOFTW.",
        "LICENCIATURA EN CIBERSEGURIDAD",
        "LIC.ING.SIST.Y COMP.",
        "MAESTRÍA EN SEGURIDAD INFORMÁT"
    };
    private String[] sexos = {
        "Masculino",
        "Femenino",
        "Gay",
        "Gay con más pasos"
    };

    public Formulario() {
        setLayout(null);
        setTitle("Formulario de Becas");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(10, 10, 100, 30);
        add(lblNombre);
        
        txtNombre = new JTextField();
        txtNombre.setBounds(120, 10, 150, 30);
        add(txtNombre);

        JLabel lblCarrera = new JLabel("Carrera:");
        lblCarrera.setBounds(10, 50, 100, 30);
        add(lblCarrera);
        
        comboCarrera = new JComboBox<>(carreras);
        comboCarrera.setBounds(120, 50, 300, 30);
        add(comboCarrera);

        JLabel lblIndice = new JLabel("Índice:");
        lblIndice.setBounds(10, 90, 100, 30);
        add(lblIndice);
        
        txtIndice = new JTextField();
        txtIndice.setBounds(120, 90, 150, 30);
        add(txtIndice);

        JLabel lblCedula = new JLabel("Cédula:");
        lblCedula.setBounds(10, 130, 100, 30);
        add(lblCedula);
        
        txtCedula = new JTextField();
        txtCedula.setBounds(120, 130, 150, 30);
        add(txtCedula);

        JLabel lblSexo = new JLabel("Sexo:");
        lblSexo.setBounds(10, 170, 100, 30);
        add(lblSexo);
        
        comboSexo = new JComboBox<>(sexos);
        comboSexo.setBounds(120, 170, 150, 30);
        add(comboSexo);

        btnAgregar = new JButton("Agregar");
        btnAgregar.setBounds(120, 210, 150, 30);
        btnAgregar.addActionListener(this);
        add(btnAgregar);
        
        JLabel lblBuscarCedula = new JLabel("Buscar por Cédula:");
        lblBuscarCedula.setBounds(10, 250, 150, 30);
        add(lblBuscarCedula);
        
        txtBuscarCedula = new JTextField();
        txtBuscarCedula.setBounds(150, 250, 120, 30);
        add(txtBuscarCedula);

        btnBuscarCedula = new JButton("Buscar");
        btnBuscarCedula.setBounds(280, 250, 90, 30);
        btnBuscarCedula.addActionListener(this);
        add(btnBuscarCedula);

        btnBuscarCarrera = new JButton("Buscar por Carrera");
        btnBuscarCarrera.setBounds(10, 290, 170, 30);
        btnBuscarCarrera.addActionListener(this);
        add(btnBuscarCarrera);

        btnBuscarSexo = new JButton("Buscar por Sexo");
        btnBuscarSexo.setBounds(190, 290, 150, 30);
        btnBuscarSexo.addActionListener(this);
        add(btnBuscarSexo);

        btnReportes = new JButton("Ver Reportes");
        btnReportes.setBounds(10, 330, 150, 30);
        btnReportes.addActionListener(this);
        add(btnReportes);
        
        becas = new Becas();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAgregar) {
            try {
                String nombre = txtNombre.getText();
                String carrera = (String) comboCarrera.getSelectedItem();
                double indice = Double.parseDouble(txtIndice.getText());
                String cedula = txtCedula.getText();
                String sexo = (String) comboSexo.getSelectedItem();
                
                
                if (indice < 0 || indice > 10) {
                    throw new IllegalArgumentException("El índice debe estar entre 0 y 10");
                }
                
               
                if (nombre.matches(".*\\d.*")) {
                    throw new IllegalArgumentException("El nombre no puede contener números");
                }
                
                Estudiantes estudiante = new Estudiantes(nombre, carrera, indice, cedula, sexo);
                becas.agregarEstudiante(estudiante);
                JOptionPane.showMessageDialog(this, "Estudiante agregado con éxito");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "El índice debe ser un número válido", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception e1) {
				
				e1.printStackTrace();
			}
        } else if (e.getSource() == btnBuscarCedula) {
            String cedula = txtBuscarCedula.getText();
            Estudiantes estudiante = becas.buscarPorCedula(cedula);
            if (estudiante != null) {
                JOptionPane.showMessageDialog(this, "Estudiante encontrado: " + estudiante.getNombre());
            } else {
                JOptionPane.showMessageDialog(this, "Estudiante no encontrado");
            }
        } else if (e.getSource() == btnBuscarCarrera) {
            String carrera = (String) comboCarrera.getSelectedItem();
            ArrayList<Estudiantes> estudiantes = becas.buscarPorCarrera(carrera);
            StringBuilder mensaje = new StringBuilder("Estudiantes en la carrera " + carrera + ":\n");
            for (Estudiantes est : estudiantes) {
                mensaje.append(est.getNombre()).append("\n");
            }
            JOptionPane.showMessageDialog(this, mensaje.toString());
        } else if (e.getSource() == btnBuscarSexo) {
            String sexo = (String) comboSexo.getSelectedItem();
            ArrayList<Estudiantes> estudiantes = becas.buscarPorSexo(sexo);
            StringBuilder mensaje = new StringBuilder("Estudiantes de sexo " + sexo + ":\n");
            for (Estudiantes est : estudiantes) {
                mensaje.append(est.getNombre()).append("\n");
            }
            JOptionPane.showMessageDialog(this, mensaje.toString());
        } else if (e.getSource() == btnReportes) {
            Reportes reportes = new Reportes();
            reportes.mostrarBecados(becas);
            reportes.setVisible(true);
        }
    }

    public static void main(String[] args) {
        Formulario formulario = new Formulario();
        formulario.setVisible(true);
    }
}
